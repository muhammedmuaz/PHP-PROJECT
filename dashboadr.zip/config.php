<?php

define('DB_Server', 'localhost');
define('DB_User', 'root');
define('DB_Pass', '');
define('DB_Table', 'fm91_rms');
$Address = 'http://localhost:8080/FM91-RMS';
$conn = mysqli_connect(DB_Server, DB_User, DB_Pass, DB_Table);
?>