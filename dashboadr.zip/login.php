<?php
include "config.php";
session_start();
// if(isset($_SESSION['username'])){
//     header("location: {$Address}/dashboadr.php");
// }
if (isset($_POST['Login'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = md5($_POST['password']);
    $sql = "SELECT * FROM `users` WHERE `username` = '{$username}' AND `password` = '{$password}'";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $_SESSION['username'] = $row['username'];
            $_SESSION['password'] = $row['password'];
        }
        header("location: {$Address}/dashboadr.php");
    } else {
        echo '
        <div class="form-group">
              <div class="alert alert-danger" role="alert">
        Login Failed
      </div>';
    }
    mysqli_close($conn);
}

if (isset($_POST['send_email'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $sql2 = "SELECT * FROM `users` WHERE `username` = '{$username}'";
    $result = mysqli_query($conn, $sql2);
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $id = $row['id'];
        $Name = $row['username'];
        $password = date("d") + mt_rand(1,3000000);
        $password_updated = md5($password);
        $sql3 = "UPDATE `users` SET `password` = '{$password_updated}' WHERE `users`.`id` = '{$id}'";
        $result = mysqli_query($conn, $sql3);
        $to = "asmanaztechnologies@gmail.com";
        $message= $password;
        $subject = "Password Updated";
        $from = "asmanaztechnologies@gmail.com";
        $headers = "From: ". $from;
       // mail($to, $subject, $message, $headers);
       echo '<div class="alert alert-success" role="alert">
        Email has been send please check
</div>';
    }
    else {
        echo '<div class="form-group">
        <div class="alert alert-danger" role="alert">
        No user available of this Name
</div>';
    }
}
else {
    echo "";
}
?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>FM91 RMS</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="css/login-style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>

<body style="background-color: #f5cb5c;">

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Forgot Password</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="/FM91-RMS/login.php" method="POST">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Please Enter your Username</label>

                            <input type="text" name="username" class="form-control" id="edit_name" aria-describedby="emailHelp" placeholder="UserName">
                        </div>
                        <button type="submit" class="btn btn-primary" name="send_email">Done</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- ReGistration Form -->
    <div class="registration-form">
        <form action="/FM91-RMS/login.php" method="post">
            <div class="form-icon">
                <span><iframe src="https://giphy.com/embed/loA8JbYQmrXo7cLrQc" frameBorder="0" class="giphy-embed"></iframe>
            </div>
            <div class="form-group">
                <input type="text" class="form-control item" name="username" id="username" placeholder="Username">
            </div>
            <div class="form-group">
                <input type="password" class="form-control item" name="password" id="password" placeholder="Password">
            </div>
            <div class="form-group">
                <button type="submit" id="btn" name="Login" class="btn btn-block create-account">Login</button>
            </div>

        </form>

        <div class="social-media">
            <h5> <a href="#" data-toggle="modal" data-target="#exampleModal"> Forgot Password ?</a></h5>
        </div>
    </div>

    <!-- Modal For Forgot Password -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
    <script src="assets/js/script.js"></script>
</body>

</html>